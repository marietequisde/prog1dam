
public class Actividad_1x02 {

	public static void main(String[] args) {
		System.out.println("PERSONA 1");

	}

}
